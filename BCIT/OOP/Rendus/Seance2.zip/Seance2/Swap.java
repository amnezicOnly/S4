import java.io.*;

public class Swap{
	public class Foo{
		String a;
		String b;
	}


	public static void swap(Object a, Object b){
		Object temp = a;
		a = b;
		b = temp;
	}

	public static void swap(Object[] x){
		Object temp = x[0];
		x[0] = x[1];
		x[1] = temp;	
	}

	//public static void swap(Foo f){
	//	Object temp = f.a;
	//	f.a = f.b;
	//	f.b = temp;
	//}


	public static void main(String[] args){
		String x = "hi";
		String y = "bye";
		String[] hold = new String[2];
		hold[0] = "foo";
		hold[1] = "bar";
		swap(hold);
		System.out.println(hold[0] + " " + hold[1]);
		swap(x,y);
		System.out.println(x);
		System.out.println(y);
	}
}
