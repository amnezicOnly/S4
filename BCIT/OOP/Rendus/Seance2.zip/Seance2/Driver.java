class Animal{
	public void draw(){
		System.out.println("animal");
	}

}

class Dog extends Animal{
	public void draw(){
		System.out.println("dog");
	}
	
	public void fetch(){
		System.out.println("fetch");
	}

}

public class Driver{
	public static void main(String[] args){
		Animal a = new Dog();
		a.draw();	// Will print dog because there is a draw method in Dog class
		Dog d = (Dog)a;	// cast évitable car tous les chiens sont des animaux
		// a.fetch() // ne fonctionnera pas car ce n'est pas nécessairement un Dog
	}
}
