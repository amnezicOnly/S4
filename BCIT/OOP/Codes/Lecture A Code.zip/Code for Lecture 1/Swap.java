public class Swap {
	// cap method 
	public static void swap(Object a, Object b){
		Object temp = a;
		a = b;
		b = temp;
	}
	public void main(String[] args){
		String x = "hi";
		String y = "hello world";
		swap(x,y);
		System.out.println(x);
	}
}
😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🤭 🤫 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢
🤢
🤢🤢
🤢
🤢
🤢
🤢
🤢
🤢
🤢

🤢
🤢

🤢

🤢
🤢
🤢
🤢

// goodbye