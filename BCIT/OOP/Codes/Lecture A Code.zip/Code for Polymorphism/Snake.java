
public class Snake extends Animal{
  public void move(){//override method inherited from Animal
    System.out.println("move like a SNAKE");
  }
  public void hiss(){//new method
    System.out.println("HISS");
  }
}