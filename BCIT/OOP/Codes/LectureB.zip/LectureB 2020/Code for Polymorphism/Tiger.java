

public class Tiger extends Animal{
  public void move(){//override method move inherited from Animal
    System.out.println("move like a TIGER");
  }
  public void growl(){//new method for Tigers
    System.out.println("ROAR");
  }
}