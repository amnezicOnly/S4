

public class Animal {
  public void move(){
    System.out.println("move like an animal");
  }
  public void talk(){
    System.out.println("talk like an animal");
  }
}