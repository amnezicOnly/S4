public class  Zoo
{
	public void bar() throws Exception{
		throw new Exception();
	}
	public void foo() throws Exception{
		try{
			System.out.println("before bar");
			bar();
			System.out.println("after bar");
		}
		catch(Exception e){
			System.out.println("exception");
			throw e;
		}
		finally{
			System.out.println("finally");
		}
		System.out.println("finished foo");
	}
	public void moo(){
		try{
			System.out.println("mooooo");
			foo();
		}catch(Exception e){
			System.out.println("moo exception");
		}
	}
	public static void main(String[] args) 
	{
		Zoo z = new Zoo();
		z.moo();
	}
}
